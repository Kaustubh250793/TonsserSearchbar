const path = require('path');
const publicPath = path.resolve(__dirname, 'public');

module.exports = {
  entry: path.resolve(__dirname, 'demo.js'),
  output: {
    path: publicPath,
    filename: 'bundle.js'
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        loader: 'babel-loader'
      },
      {
        test: /\.css$/,
        loaders: [
          'style-loader',
          'css-loader?modules&camelCase&importLoaders=1&localIdentName=[name]__[local]___[hash:base64:5]'
        ]
      },
      {
        test: /\.(jpe?g|png|gif|svg)$/i,
        loaders: [
          'file-loader?hash=sha512&digest=hex&name=[hash].[ext]',
          'image-webpack-loader?bypassOnDebug&optimizationLevel=7&interlaced=true'
        ]
      } 
    ]
  },
  devServer: {
    contentBase: publicPath,
    noInfo: true
  },
  devtool: 'source-map'
};
