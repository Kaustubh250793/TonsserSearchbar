import React from 'react';
import ReactDOM from 'react-dom';
import autoBind from 'react-autobind';

import SearchBar from '../src';
import styles from './demo.css';
import words from './words.json';
import logo from './images/logo.png';

class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      suggestions: []
    };

    autoBind(this, 'handleChange', 'handleClear', 'handleSelection');
  }

  handleClear() {
    this.setState({
      suggestions: []
    });
  }

  handleChange(input) {
    fetch('https://api.tonsser.com/59/clubs/search?query='+input, {
        mode: 'cors', 
        headers: {
          'Access-Control-Allow-Origin': '*'
        }
      })
    .then(res => res.json())
    .then(data => {
      this.setState({
        suggestions: data.clubs.map(club => club.name)
      });
      console.log('data', data)
    })
    .catch(err => console.log('error', err));
  }

  handleSelection(value) {
    if (value) {
      console.info(`Selected "${value}"`);
    }
  }

  handleSearch(value) {
    if (value) {
      console.info(`Searching "${value}"`);
    }
  }

  suggestionRenderer(suggestion, searchTerm) {
    return (
      <span>
        <span>{searchTerm}</span>
        <strong>{suggestion.substr(searchTerm.length)}</strong>
      </span>
    );
  }

  render() {
    return (
      <div style={{ background : 'black', display: 'flex', justifyContent: 'space-around', alignItems: 'center', width: '100%', height: '100px' }}>
        <img src={logo} alt="tonsser logo" />
        <div style={{ width: '15%', padding: '10px', minWidth: '300px' }}>
          <SearchBar
            autoFocus
            renderClearButton
            renderSearchButton
            placeholder="search"
            onChange={this.handleChange}
            onClear={this.handleClear}
            onSelection={this.handleSelection}
            onSearch={this.handleSearch}
            suggestions={this.state.suggestions}
            suggestionRenderer={this.suggestionRenderer}
            styles={styles}
          />
        </div>
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
