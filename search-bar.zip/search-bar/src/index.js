export { default } from './components/search-bar';
